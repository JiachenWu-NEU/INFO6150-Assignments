# INFO6150-Assignment1
# Japanese Battleships · Data Archive

## Simple Description
This is a website used for demonstrating information about Japanese battleships, using HTML + CSS
There are four main views: overview, info of Yamato Class battleships, info of Nagato Class battleships and a login demo.
Besides the login, all pages want to show you information of these battleships, like carlibar, weight and built year.
The login page is just a demo. There are necessary input items but the login button just show what you input and will not login exactly.

Tags used:
- `html`, `head`, `meta`, `title`, `link`, `script`

- `header`, `nav`, `main`, `section`, `article`, `aside`, `footer`

- `h1`, `h2`, `h3`, `p`, `ul`, `li`, `code`, `details`, `summary`

- `button`

- `table`, `thead`, `tbody`, `tr`, `th`, `td`

- `a`

- `form`, `fieldset`, `label`, `input`, `datalist`, `option`
